---
name: Security Issue
about: Report a security issue with DNN
---
## DO NOT REPORT SECURITY ISSUES VIA GITHUB
Any potential security issues must sent to security@dnnsoftware.com, rather than posted on GitHub
