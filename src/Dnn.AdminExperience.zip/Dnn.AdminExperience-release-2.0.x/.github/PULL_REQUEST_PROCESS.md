# DNN Platform Pull Request Proceseses

Please review the main process guide on the [Dnn:Platform repository](https://github.com/dnnsoftware/Dnn.Platform/blob/development/.github/PULL_REQUEST_PROCESS.md).
