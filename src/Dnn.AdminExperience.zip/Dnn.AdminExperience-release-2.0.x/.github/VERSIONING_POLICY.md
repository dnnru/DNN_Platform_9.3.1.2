# DNN Platform Versioning and Deprecation Policies

Please review the main versioning policy on the (Dnn:Platform repository)[https://github.com/dnnsoftware/Dnn.Platform/blob/development/.github/VERSIONING_POLICY.md].




