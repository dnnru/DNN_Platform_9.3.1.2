﻿namespace Dnn.PersonaBar.Pages.Components
{
    public class Constants
    {
        internal const string LocalResourceFile = Library.Constants.PersonaBarRelativePath + "Modules/Dnn.Pages/App_LocalResources/Pages.resx";
        public const string PagesCategory = "Prompt_PagesCategory";
    }
}