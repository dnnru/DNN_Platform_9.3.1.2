﻿namespace Dnn.PersonaBar.Pages.Components.Dto
{
    public class Template
    {
        public string Id { get; set; }
        public int Value { get; set; }
    }
}