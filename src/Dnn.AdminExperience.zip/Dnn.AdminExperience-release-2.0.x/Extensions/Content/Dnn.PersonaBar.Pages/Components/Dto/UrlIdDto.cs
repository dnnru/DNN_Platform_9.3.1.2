﻿namespace Dnn.PersonaBar.Pages.Components.Dto
{
    public class UrlIdDto
    {
        public int TabId { get; set; }
        public int Id { get; set; }
    }
}