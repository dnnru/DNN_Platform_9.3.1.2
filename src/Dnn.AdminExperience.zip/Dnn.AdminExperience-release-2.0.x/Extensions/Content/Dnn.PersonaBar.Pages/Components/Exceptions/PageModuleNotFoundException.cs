﻿using System;

namespace Dnn.PersonaBar.Pages.Components.Exceptions
{
    public class PageModuleNotFoundException : Exception
    {
    }
}