﻿using System;

namespace Dnn.PersonaBar.Pages.Components.Exceptions
{
    public class PageNotFoundException : Exception
    {
    }
}