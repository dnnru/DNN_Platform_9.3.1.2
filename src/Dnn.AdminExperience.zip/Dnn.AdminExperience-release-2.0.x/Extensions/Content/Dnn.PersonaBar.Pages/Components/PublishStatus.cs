﻿#region Copyright
// DotNetNuke® - http://www.dotnetnuke.com
// Copyright (c) 2002-2018
// by DotNetNuke Corporation
// All Rights Reserved
#endregion

namespace Dnn.PersonaBar.Pages.Components
{
    public enum PublishStatus
    {
        All,
        Published,
        Draft
    }
}
