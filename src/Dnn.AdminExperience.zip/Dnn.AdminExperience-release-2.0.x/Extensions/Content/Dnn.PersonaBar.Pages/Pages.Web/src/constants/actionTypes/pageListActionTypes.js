const pageListActionTypes =  {
    SAVE: "SAVE"
};

export default pageListActionTypes;