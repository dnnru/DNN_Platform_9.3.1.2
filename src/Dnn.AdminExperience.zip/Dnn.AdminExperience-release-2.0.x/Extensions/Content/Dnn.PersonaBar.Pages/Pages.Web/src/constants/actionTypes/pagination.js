const paginationActionTypes =  {    
    LOAD_MORE: "LOAD_MORE",
    LOAD_TAB_DATA: "LOAD_TAB_DATA"
};
export default paginationActionTypes;
