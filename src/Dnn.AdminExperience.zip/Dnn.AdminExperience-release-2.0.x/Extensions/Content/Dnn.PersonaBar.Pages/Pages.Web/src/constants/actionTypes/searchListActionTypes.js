const searchListActionTypes =  {
    SAVE_SEARCH_LIST: "SAVE_SEARCH_LIST",
    SAVE_SEARCH_RESULT: "SAVE_SEARCH_RESULT"
};

export default searchListActionTypes;