const visiblePageSettingsActionTypes = {
    HIDE_CUSTOM_PAGE_SETTINGS : "HIDE_CUSTOM_PAGE_SETTINGS",
    SHOW_CUSTOM_PAGE_SETTINGS : "SHOW_CUSTOM_PAGE_SETTINGS"
};

export default visiblePageSettingsActionTypes;