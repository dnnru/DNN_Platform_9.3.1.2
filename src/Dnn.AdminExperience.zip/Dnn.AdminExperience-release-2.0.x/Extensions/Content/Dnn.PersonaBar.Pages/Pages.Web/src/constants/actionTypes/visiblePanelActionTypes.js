const visiblePanelActionTypes =  {    
    SHOW_PANEL: "SHOW_PANEL",
    HIDE_PANEL: "HIDE_PANEL"
};
export default visiblePanelActionTypes;
