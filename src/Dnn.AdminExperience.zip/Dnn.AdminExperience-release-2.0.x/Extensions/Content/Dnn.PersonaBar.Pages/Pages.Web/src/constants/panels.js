const panels =  {    
    MAIN_PANEL: 0,   
    PAGE_SETTINGS_PANEL: 1,
    ADD_MULTIPLE_PAGES_PANEL: 2,
    SAVE_AS_TEMPLATE_PANEL: 3,
    CUSTOM_PAGE_DETAIL_PANEL: 4
};
export default panels;
