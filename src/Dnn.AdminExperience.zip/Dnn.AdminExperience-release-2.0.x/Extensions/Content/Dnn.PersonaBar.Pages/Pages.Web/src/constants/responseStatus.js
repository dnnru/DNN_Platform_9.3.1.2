const responseStatus =  {    
    OK: 0,   
    ERROR: 1
};
export default responseStatus;
