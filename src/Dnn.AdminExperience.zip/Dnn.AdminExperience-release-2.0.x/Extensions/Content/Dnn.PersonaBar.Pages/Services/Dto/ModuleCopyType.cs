﻿namespace Dnn.PersonaBar.Pages.Services.Dto
{
    public enum ModuleCopyType
    {
        New,
        Copy,
        Reference
    }
}