const paginationActionTypes =  {    
    SELECT_PANEL: "SELECT_PANEL"
};
export default paginationActionTypes;
