﻿namespace Dnn.PersonaBar.Roles.Components
{ 
    public static class Constants
    {
        public const string MenuName = "Dnn.Roles";
        public const string RolesCategory = "Prompt_RolesCategory";
        public const string LocalResourcesFile = "~/DesktopModules/admin/Dnn.PersonaBar//Modules/Dnn.Roles/App_LocalResources/Roles.resx";
    }
}