﻿using System;

namespace Dnn.PersonaBar.Roles.Components.Prompt.Exceptions
{
    public class SetRoleException : Exception
    {
        public SetRoleException(string message) : base(message)
        { }
    }

}
