﻿namespace Dnn.PersonaBar.Sites.Components
{
    public static class Constants
    {
        public const string LocalResourcesFile = "~/DesktopModules/admin/Dnn.PersonaBar/Modules/Dnn.Sites/App_LocalResources/Sites.resx";
    }
}