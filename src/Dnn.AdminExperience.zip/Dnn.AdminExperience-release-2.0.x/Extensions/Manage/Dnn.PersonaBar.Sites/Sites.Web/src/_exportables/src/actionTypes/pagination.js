const paginationActionTypes = {
    LOAD_MORE: "LOAD_MORE"
};
export default paginationActionTypes;
