const visiblePanelActionTypes =  {    
    SELECT_PANEL: "SELECT_PANEL"
};
export default visiblePanelActionTypes;
