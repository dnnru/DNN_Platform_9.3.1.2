﻿
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace DNNConnect.CKEditorProvider {
    
    
    public partial class Options {
        
        /// <summary>
        /// favicon control.
        /// </summary>
        /// <remarks>
        /// Auto-generated field.
        /// To modify move field declaration from designer file to code-behind file.
        /// </remarks>
        protected PlaceHolder favicon;
        
        /// <summary>
        /// ckOptionsForm control.
        /// </summary>
        /// <remarks>
        /// Auto-generated field.
        /// To modify move field declaration from designer file to code-behind file.
        /// </remarks>
        protected HtmlForm ckOptionsForm;
        
        /// <summary>
        /// phControls control.
        /// </summary>
        /// <remarks>
        /// Auto-generated field.
        /// To modify move field declaration from designer file to code-behind file.
        /// </remarks>
        protected PlaceHolder phControls;
    }
}
