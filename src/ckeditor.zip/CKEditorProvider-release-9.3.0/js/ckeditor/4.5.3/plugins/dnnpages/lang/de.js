CKEDITOR.plugins.setLang('dnnpages','de',{
    dnnpages: 'Portal Seite',
    fileToBig: 'Datei ist zu groß zum hochladen.',
	localPageLabel : 'Seite innerhalb des Portals',
	localPageTitle: 'Wählen Sie die Seite aus Ihrem Portal, auf die Sie verlinken möchten',
	portalUrl: 'Portal Datei oder andere URL'
});