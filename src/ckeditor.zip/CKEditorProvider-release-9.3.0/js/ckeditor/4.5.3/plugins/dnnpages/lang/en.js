CKEDITOR.plugins.setLang('dnnpages', 'en', {
    dnnpages: 'Portal Page',
    fileToBig: 'File is to big to upload.',
	localPageLabel : 'Page from within your Portal',
	localPageTitle: 'Select the page from within your portal that you would like to link to',
	portalUrl: 'Portal file or other URL'
});