CKEDITOR.plugins.setLang('dnnpages', 'pl', {
    dnnpages: 'Strona w witrynie',
    fileToBig: 'File is to big to upload.',
    localPageLabel: 'Strona znajdująca się w witrynie',
	localPageTitle: 'Proszę wybrać stronę w witrynie, do której ma zostać utworzony odnośnik',
	portalUrl: 'Plik witryny lub inny adres URL'
});