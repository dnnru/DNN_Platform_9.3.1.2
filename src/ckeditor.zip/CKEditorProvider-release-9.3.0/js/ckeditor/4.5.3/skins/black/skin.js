﻿/*
Copyright (c) CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.skin.name = 'black';
CKEDITOR.skin.ua_dialog = 'opera,ie';
CKEDITOR.skin.ua_editor="ie";
