﻿# CKEditorProvider
[![Build status](https://ci.appveyor.com/api/projects/status/wbntx8fcsnjwbht3/branch/development?svg=true)](https://ci.appveyor.com/project/OliverHine/ckeditorprovider/branch/development)
[![Join the chat at https://gitter.im/DNN-Connect/CKEditorProvider](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/DNN-Connect/CKEditorProvider?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge) 

An HTML Editor Provider for DNN using the CKEditor.
