﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClientDependency.Core.Controls
{
	public class ClientDependencyPathCollection : List<ClientDependencyPath>
	{

	}
}
