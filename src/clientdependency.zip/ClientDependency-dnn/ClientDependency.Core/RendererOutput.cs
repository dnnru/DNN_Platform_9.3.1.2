﻿namespace ClientDependency.Core
{
    internal class RendererOutput
    {
        public string Name { get; set; }
        public string OutputJs { get; set; }
        public string OutputCss { get; set; }
    }
}