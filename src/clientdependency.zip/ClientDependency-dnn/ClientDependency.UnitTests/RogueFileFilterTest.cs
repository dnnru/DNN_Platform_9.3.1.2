﻿using ClientDependency.Core.Module;
using NUnit.Framework;
using System;

namespace ClientDependency.UnitTests
{
    
    
    /// <summary>
    ///This is a test class for RogueFileFilterTest and is intended
    ///to contain all RogueFileFilterTest Unit Tests
    ///</summary>
    [TestFixture]
    public class RogueFileFilterTest
    {

        /// <summary>
        ///A test for CanExecute
        ///</summary>
        [Test]
        public void RogueFiles_Can_Execute()
        {
           
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for UpdateOutputHtml
        ///</summary>
        [Test]
        public void RogueFiles_Update_Output_Html()
        {
           
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///A test for ValidateCurrentHandler
        ///</summary>
        [Test]
        public void RogueFiles_Validate_Current_Handler()
        {
           
            Assert.Inconclusive("Verify the correctness of this test method.");
        }
    }
}
