function ANSIEncoding() {
	alert("Testing ANSI encoding");
}
ANSIEncoding();