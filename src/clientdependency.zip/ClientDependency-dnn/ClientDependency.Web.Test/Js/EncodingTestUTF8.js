﻿function UTF8Encoding() {
	alert("Testing UTF8 encoding with BOM");
}
UTF8Encoding();