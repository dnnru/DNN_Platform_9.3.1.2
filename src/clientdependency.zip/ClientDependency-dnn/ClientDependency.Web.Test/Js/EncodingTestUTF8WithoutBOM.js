function UTF8EncodingWithoutBOM() {
	alert("Testing UTF8 encoding file without BOM");
}
UTF8EncodingWithoutBOM();
