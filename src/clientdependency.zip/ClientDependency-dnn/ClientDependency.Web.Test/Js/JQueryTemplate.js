﻿<div data-bind="html: myVariable">    
</div>