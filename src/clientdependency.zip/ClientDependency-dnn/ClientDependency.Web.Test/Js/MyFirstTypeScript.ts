﻿function greeter(person: string) {
    return "Hello, " + person;
}
var user = "Jane User";
alert(greeter(user));