﻿(function ($) {

    $(document).ready(function () {

        $(".header").css("background-color", "orange");
        $(".header").css("background-image", "none");

    });

})(jQuery);