﻿using System.Reflection;
using System.Security;

[assembly: AssemblyCompany("Shannon Deminick")]
[assembly: AssemblyCopyright("Copyright © Shannon Deminick 2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]


[assembly: AssemblyVersion("1.9.2")]
[assembly: AssemblyFileVersion("1.9.2")]
[assembly: AssemblyInformationalVersion("1.9.2")]
